// frontend/js/api.js
// Модуль для работы с API почтового клиента

import Config from './config.js'

class MainAPI {
  constructor() {
    this.baseUrl = Config.API_BASE_URL
    this.cache = new Map() // Кэш ответов
    this.requestQueue = new Map() // Очередь активных запросов
  }

  // Приватный метод выполнения запроса
  async #makeRequest(endpoint, options = {}) {
    const cacheKey = `${endpoint}_${JSON.stringify(options)}`

    // 1. Проверка кэша
    if (this.cache.has(cacheKey)) {
      const cached = this.cache.get(cacheKey)
      if (Date.now() - cached.timestamp < Config.CACHE_TIME) {
        console.log(`📦 Используем кэш: ${endpoint}`)
        return cached.data
      }
      this.cache.delete(cacheKey)
    }

    // 2. Проверка дублирующегося активного запроса
    if (this.requestQueue.has(cacheKey)) {
      console.log(`📦 Используем существующий запрос: ${endpoint}`)
      return this.requestQueue.get(cacheKey)
    }

    // 3. Создаём Promise запроса
    const requestPromise = (async () => {
      for (let attempt = 1; attempt <= Config.RETRY_ATTEMPTS; attempt++) {
        try {
          const controller = new AbortController()
          const timeoutId = setTimeout(
            () => controller.abort(),
            Config.REQUEST_TIMEOUT
          )

          const response = await fetch(`${this.baseUrl}${endpoint}`, {
            ...options,
            signal: controller.signal,
            headers: {
              'Content-Type': 'application/json',
              ...options.headers,
            },
          })

          clearTimeout(timeoutId)

          if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`)
          }

          const data = await response.json()

          // Кэшируем успешный ответ
          this.cache.set(cacheKey, {
            data,
            timestamp: Date.now(),
          })

          console.log(`✅ Успешный ответ: ${endpoint}`)
          return data
        } catch (error) {
          if (attempt === Config.RETRY_ATTEMPTS) {
            throw error
          }
          await new Promise((resolve) =>
            setTimeout(resolve, Config.RETRY_DELAY)
          )
        }
      }
    })()

    // 4. Сохраняем активный запрос
    this.requestQueue.set(cacheKey, requestPromise)

    try {
      return await requestPromise
    } finally {
      // 5. Удаляем из очереди после завершения
      this.requestQueue.delete(cacheKey)
    }
  }

  // ===============================
  // Публичные методы API
  // ===============================

  async getLetters(folder = null) {
    let endpoint = Config.API_ENDPOINTS.LETTERS
    if (folder) endpoint += `?folder=${folder}`
    return await this.#makeRequest(endpoint)
  }

  async getLetterById(id) {
    const endpoint = Config.API_ENDPOINTS.LETTER_BY_ID.replace(':id', id)
    return await this.#makeRequest(endpoint)
  }

  async createLetter(letterData) {
    return await this.#makeRequest(Config.API_ENDPOINTS.LETTERS, {
      method: 'POST',
      body: JSON.stringify(letterData),
    })
  }

  async updateLetter(id, updates) {
    const endpoint = Config.API_ENDPOINTS.LETTER_BY_ID.replace(':id', id)
    return await this.#makeRequest(endpoint, {
      method: 'PATCH',
      body: JSON.stringify(updates),
    })
  }

  async deleteLetter(id) {
    const endpoint = Config.API_ENDPOINTS.LETTER_BY_ID.replace(':id', id)
    return await this.#makeRequest(endpoint, { method: 'DELETE' })
  }

  async getLettersByFolder(folderName) {
    const endpoint = Config.API_ENDPOINTS.FOLDERS.replace(':name', folderName)
    return await this.#makeRequest(endpoint)
  }

  // Проверка доступности сервера
  async checkServerHealth() {
    try {
      const serverUrl = this.baseUrl.replace('/api', '')
      const response = await fetch(`${serverUrl}/`, { method: 'HEAD' })
      return response.ok
    } catch {
      return false
    }
  }

  // Групповая загрузка запросов
  async batchRequests(endpoints) {
    if (!Array.isArray(endpoints)) {
      throw new Error('batchRequests ожидает массив endpoint-ов')
    }

    const requests = endpoints.map((endpoint) => this.#makeRequest(endpoint))

    return Promise.all(requests)
  }

  // Очистка кэша
  clearCache(pattern = null) {
    if (!pattern) {
      this.cache.clear()
      return
    }

    for (const key of this.cache.keys()) {
      if (key.includes(pattern)) {
        this.cache.delete(key)
      }
    }
  }
}

// Экспортируем singleton
export default new MainAPI()
