// frontend/js/app.js
import api from './api.js'

let currentLetterId = null
// Нормализованные ключи папок: используем 'inbox', 'sent', 'draft', 'trash', 'all'
let currentFolder = loadPersistedFolder() || 'inbox'
let allLetters = []
let displayedLetters = []

// -----------------------------
// ПАГИНАЦИЯ
// -----------------------------
let currentPage = 1
const LETTERS_PER_PAGE = 10
let totalPages = 1

function displayLettersWithPagination(letters) {
  // letters — полный набор, который нужно пагинировать (локальный displayedLetters)
  displayedLetters = Array.isArray(letters) ? letters.slice() : []
  currentPage = 1
  totalPages = Math.max(
    1,
    Math.ceil(displayedLetters.length / LETTERS_PER_PAGE)
  )
  updateDisplayedLetters()
  setupPagination()
}

function updateDisplayedLetters() {
  const startIndex = (currentPage - 1) * LETTERS_PER_PAGE
  const endIndex = startIndex + LETTERS_PER_PAGE
  const lettersToShow = displayedLetters.slice(startIndex, endIndex)
  displayLetters(lettersToShow)
  setupPagination()
  return lettersToShow
}

function setupPagination() {
  const paginationContainer = document.getElementById('pagination-container')
  if (!paginationContainer) return

  totalPages = Math.max(
    1,
    Math.ceil(displayedLetters.length / LETTERS_PER_PAGE)
  )

  if (totalPages <= 1) {
    paginationContainer.style.display = 'none'
    return
  }

  paginationContainer.style.display = 'flex'

  const maxShown = Math.min(5, totalPages)
  let html = ''

  html += `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
    <a class="page-link" href="#" data-action="prev" aria-label="Назад">Назад</a>
  </li>`

  for (let i = 1; i <= maxShown; i++) {
    html += `<li class="page-item ${currentPage === i ? 'active' : ''}">
      <a class="page-link" href="#" data-page="${i}">${i}</a>
    </li>`
  }

  if (totalPages > maxShown) {
    html += `<li class="page-item disabled"><span class="page-link">...</span></li>`
    html += `<li class="page-item ${
      currentPage === totalPages ? 'active' : ''
    }">
      <a class="page-link" href="#" data-page="${totalPages}">${totalPages}</a>
    </li>`
  }

  html += `<li class="page-item ${
    currentPage === totalPages ? 'disabled' : ''
  }">
    <a class="page-link" href="#" data-action="next" aria-label="Вперед">Вперед</a>
  </li>`

  paginationContainer.innerHTML = html

  // Повесим единый обработчик (перезаписывается при каждом setup)
  paginationContainer.onclick = function (e) {
    const a = e.target.closest('a.page-link')
    if (!a) return
    e.preventDefault()

    const action = a.dataset.action
    if (action === 'prev' && currentPage > 1) {
      currentPage--
      updateDisplayedLetters()
      return
    }
    if (action === 'next' && currentPage < totalPages) {
      currentPage++
      updateDisplayedLetters()
      return
    }

    // specific page
    const page = a.dataset.page ? parseInt(a.dataset.page, 10) : null
    if (page && page !== currentPage) {
      currentPage = page
      updateDisplayedLetters()
      return
    }
  }
}

// -----------------------------
// Folder map / helpers
// -----------------------------
const FOLDER_MAP = {
  inbox: { keys: ['inbox', 'Входящие'], display: 'Входящие' },
  sent: { keys: ['sent', 'Отправленные'], display: 'Отправленные' },
  draft: { keys: ['draft', 'Черновики'], display: 'Черновики' },
  trash: { keys: ['trash', 'Корзина'], display: 'Корзина' },
  all: { keys: ['all', 'Все письма'], display: 'Все письма' },
}

function normalizeFolder(input) {
  if (!input) return 'inbox'
  const s = String(input)
  for (const key of Object.keys(FOLDER_MAP)) {
    // ищем по набору ключей (включая русские значения)
    if (FOLDER_MAP[key].keys.includes(s)) return key
  }
  // если передан уже нормализованный ключ (inbox/sent/...)
  const low = s.toLowerCase()
  if (Object.keys(FOLDER_MAP).includes(low)) return low
  // fallback — пытаемся вернуть оригинал (нечастый случай)
  return s
}

function displayNameForFolder(key) {
  return FOLDER_MAP[key]?.display || key
}

function persistFolder(key) {
  try {
    localStorage.setItem('mail_currentFolder', key)
  } catch (e) {}
}

function loadPersistedFolder() {
  try {
    return localStorage.getItem('mail_currentFolder')
  } catch (e) {
    return null
  }
}

// -----------------------------
// Инициализация
// -----------------------------
document.addEventListener('DOMContentLoaded', async () => {
  updateCurrentDate()
  setupEventListeners()

  // Проверьте доступность сервера и загрузите начальные данные
  await checkServerStatus()
  await loadInitialData()
})

// -----------------------------
// Setup / Event listeners
// -----------------------------
function setupEventListeners() {
  // Папки (делегирование)
  document.querySelectorAll('[data-folder]').forEach((item) => {
    item.addEventListener('click', async (e) => {
      e.preventDefault()
      const folderRaw = item.getAttribute('data-folder')
      await selectFolder(folderRaw, item)
    })
  })

  // Новое письмо (десктоп)
  const newLetterBtn = document.getElementById('new-letter-btn')
  if (newLetterBtn)
    newLetterBtn.addEventListener('click', () => showNewLetterForm(false))

  // Мобильная кнопка
  const mobileNewLetterBtn = document.getElementById('mobile-new-letter')
  if (mobileNewLetterBtn)
    mobileNewLetterBtn.addEventListener('click', () => showNewLetterForm(false))

  // Обновить (кнопка рядом с "Письма")
  const refreshBtn =
    document.querySelector('#refresh-letters-btn') ||
    document.querySelector('.btn-group .btn:first-child')
  if (refreshBtn)
    refreshBtn.addEventListener('click', async () => {
      await refreshAllData()
      // после ручного обновления остаёмся в текущей папке
      await filterLettersByFolder(currentFolder, { selectFirst: false })
    })

  // Поиск — с дебаунсом (десктоп)
  const searchInput = document.querySelector('.search-box input')
  if (searchInput) {
    let searchTimeout
    searchInput.addEventListener('input', function (e) {
      clearTimeout(searchTimeout)
      searchTimeout = setTimeout(() => {
        filterLettersBySearch(this.value)
      }, 300)
    })
  }

  // Поиск в мобильном меню
  const mobileSearchInput = document.getElementById('mobile-search-input')
  if (mobileSearchInput) {
    const debouncedMobile = debounce(
      (e) => filterLettersBySearch(e.target.value),
      250
    )
    mobileSearchInput.addEventListener('input', debouncedMobile)
  }

  // Форма нового письма
  setupNewLetterForm()

  // Клик по письму (делегирование)
  const letterList = document.getElementById('letter-list')
  if (letterList) {
    letterList.addEventListener('click', async (e) => {
      const item = e.target.closest('.list-group-item')
      if (!item) return
      const id = item.getAttribute('data-id')
      if (id) {
        await selectLetter(Number(id), item)
      }
    })
  }
}

// -----------------------------
// Server / initial data
// -----------------------------
async function checkServerStatus() {
  const statusElement = document.getElementById('server-status')
  try {
    const isHealthy = await api.checkServerHealth()
    if (isHealthy) {
      statusElement.innerHTML =
        '<i class="bi bi-check-circle me-1" aria-hidden="true"></i>API онлайн'
      statusElement.className = 'badge bg-success'
    } else {
      throw new Error('Сервер вернул негативный статус')
    }
  } catch (err) {
    if (statusElement) {
      statusElement.innerHTML =
        '<i class="bi bi-x-circle me-1" aria-hidden="true"></i>API офлайн'
      statusElement.className = 'badge bg-danger'
    }
    showError('Сервер API недоступен. Проверьте, запущен ли backend сервер.')
  }
}

async function loadInitialData() {
  showLoading('Загрузка писем...')
  try {
    const response = await api.getLetters()
    if (!response || !response.success) {
      throw new Error('Неверный формат ответа сервера')
    }

    allLetters = Array.isArray(response.data) ? response.data : []

    // Восстановим папку из localStorage (если есть) или используем currentFolder
    const stored = loadPersistedFolder()
    const folderToOpen = stored
      ? normalizeFolder(stored)
      : normalizeFolder(currentFolder)
    currentFolder = folderToOpen
    persistFolder(currentFolder)

    // Показываем письма в выбранной папке
    await filterLettersByFolder(currentFolder, { selectFirst: true })

    hideLoading()
  } catch (err) {
    showError(`Не удалось загрузить письма: ${err.message}`)
    hideLoading()
  }
}

// -----------------------------
// Display / rendering letters
// -----------------------------
function displayLetters(letters) {
  const letterList = document.getElementById('letter-list')
  if (!letterList) return

  if (!letters || letters.length === 0) {
    letterList.innerHTML = `
      <div class="text-center py-5 text-muted">
        <i class="bi bi-envelope display-6" aria-hidden="true"></i>
        <p class="mt-3 mb-0">Нет писем</p>
      </div>
    `
    return
  }

  // Очистка и создание элементов
  letterList.innerHTML = ''
  const fragment = document.createDocumentFragment()

  letters.forEach((letter) => {
    const el = createLetterElement(letter)
    fragment.appendChild(el)
  })

  letterList.appendChild(fragment)
}

function createLetterElement(letter) {
  const isUnread = Number(letter.is_read) === 0
  const date = formatDate(letter.date || letter.created_at)

  const a = document.createElement('a')
  a.href = '#'
  a.className = `list-group-item list-group-item-action ${
    isUnread ? 'unread' : ''
  }`
  a.setAttribute('data-id', letter.id)
  a.setAttribute('role', 'button')
  a.setAttribute(
    'aria-label',
    `${letter.subject || 'Без темы'} — от ${
      letter.from_email || 'Неизвестный отправитель'
    }`
  )

  const sender = escapeHtml(
    letter.from_email || letter.sender_email || 'Неизвестный отправитель'
  )
  const subj = escapeHtml(letter.subject || 'Без темы')
  const preview = escapeHtml(truncateText(letter.body || '', 80))

  a.innerHTML = `
    <div class="d-flex w-100 justify-content-between">
      <h6 class="mb-1 ${isUnread ? 'fw-bold' : ''}">${sender}</h6>
      <small class="text-muted">${date}</small>
    </div>
    <p class="mb-1 ${isUnread ? 'fw-bold' : ''}">${subj}</p>
    <small class="text-muted">${preview}</small>
  `
  return a
}

// -----------------------------
// Folders / filtering
// -----------------------------
async function selectFolder(
  rawFolder,
  element = null,
  options = { selectFirst: true }
) {
  const folder = normalizeFolder(rawFolder)
  currentFolder = folder
  persistFolder(currentFolder)

  // Убираем active со всех
  document
    .querySelectorAll('[data-folder]')
    .forEach((item) => item.classList.remove('active'))

  // Попытаемся найти элемент в DOM соответствующий нашей нормализованной папке.
  if (!element) {
    element =
      Array.from(document.querySelectorAll('[data-folder]')).find((it) => {
        const val = it.getAttribute('data-folder')
        return val === folder || FOLDER_MAP[folder]?.keys.includes(val)
      }) || null
  }
  if (element) element.classList.add('active')

  await filterLettersByFolder(folder, { selectFirst: options.selectFirst })
}

async function filterLettersByFolder(folder, options = { selectFirst: true }) {
  showLoading(`Загрузка писем "${displayNameForFolder(folder)}"...`)
  try {
    // Поддерживаем 'all' — показываем все письма
    if (folder === 'all') {
      displayedLetters = [...allLetters]
    } else {
      displayedLetters = allLetters.filter((letter) => {
        const lf = normalizeFolder(
          letter.folder || letter.folder_name || letter.folderKey
        )
        return lf === folder
      })
    }

    // <- ЗАМЕНЕНО: используем пагинацию
    displayLettersWithPagination(displayedLetters)

    updateStatistics(allLetters)

    // reset selection
    resetLetterSelection()

    // Опция: выбрать первый элемент в папке (по умолчанию true)
    if (options.selectFirst && displayedLetters.length > 0) {
      // выберем первый видимый элемент на странице
      const shown = updateDisplayedLetters()
      if (shown && shown.length > 0) {
        await selectLetter(shown[0].id)
      }
    }

    hideLoading()
  } catch (err) {
    showError(`Не удалось загрузить письма: ${err.message}`)
    hideLoading()
  }
}

// -----------------------------
// Select / view letter
// -----------------------------
/**
 * selectLetter(letterId, element = null, options = { markReadOnSelect: true, loadFromServer: true })
 * - markReadOnSelect: при true — если элемент имеет класс 'unread' и передан DOM-элемент, вызовет markAsRead()
 * - loadFromServer: при true — загрузит письмо с сервера через api.getLetterById; при false — использует локальную запись из allLetters
 */
async function selectLetter(
  letterId,
  element = null,
  options = { markReadOnSelect: true, loadFromServer: true }
) {
  currentLetterId = letterId

  // Убираем выделение в списке
  document
    .querySelectorAll(
      '.letter-list .list-group-item, #letter-list .list-group-item'
    )
    .forEach((it) => it.classList.remove('active-letter'))
  if (element) element.classList.add('active-letter')

  // Пометить прочитанным только при опции markReadOnSelect === true
  if (
    element &&
    options.markReadOnSelect &&
    element.classList.contains('unread')
  ) {
    await markAsRead(letterId, element)
  }

  if (options.loadFromServer) {
    await loadLetterContent(letterId)
  } else {
    // Попытаемся найти локальную запись и показать её без запроса к серверу
    const local = allLetters.find((l) => Number(l.id) === Number(letterId))
    if (local) {
      displayLetterContent(local)
    } else {
      // если нет локально — загружаем с сервера как fallback
      await loadLetterContent(letterId)
    }
  }
}

async function loadLetterContent(letterId) {
  showLoading('Загрузка письма...')
  try {
    const response = await api.getLetterById(letterId)
    if (!response || !response.success)
      throw new Error('Не удалось загрузить письмо')

    displayLetterContent(response.data)
    hideLoading()
  } catch (err) {
    showError(`Не удалось загрузить письмо: ${err.message}`)
    hideLoading()
  }
}

function displayLetterContent(letter) {
  // Прячем заглушку
  const noSelected = document.getElementById('no-letter-selected')
  const content = document.getElementById('letter-content')
  if (noSelected) noSelected.style.display = 'none'
  if (content) content.style.display = 'block'

  // Заполняем поля (с защитой от null)
  setTextContent('#letter-subject', letter.subject || 'Без темы')
  setTextContent(
    '#letter-from',
    letter.from_email || letter.sender_email || 'Неизвестный отправитель'
  )
  setTextContent(
    '#letter-to',
    letter.to_email || letter.recipient_email || 'Неизвестный получатель'
  )
  setTextContent('#letter-date', formatDate(letter.date || letter.created_at))
  setTextContent(
    '#letter-folder',
    displayNameForFolder(normalizeFolder(letter.folder))
  )

  // Тело
  const letterBodyEl = document.getElementById('letter-body')
  if (letterBodyEl) {
    letterBodyEl.innerHTML = (
      letter.body || 'Текст письма отсутствует'
    ).replace(/\n/g, '<br>')
  }

  // Обновляем бейджи папки
  updateLetterBadges(letter)
  // Настраиваем кнопки действий (включая редактирование черновиков)
  setupLetterActionButtons(letter.id, letter)
}

// -----------------------------
// Actions: mark read, delete, update stats
// -----------------------------
async function markAsRead(letterId, element) {
  try {
    await api.updateLetter(letterId, { is_read: 1 })

    // Обновляем локальные массивы
    const li = allLetters.find((l) => l.id === letterId)
    if (li) li.is_read = 1
    const dl = displayedLetters.find((l) => l.id === letterId)
    if (dl) dl.is_read = 1

    if (element) {
      element.classList.remove('unread')
      element
        .querySelectorAll('.fw-bold')
        .forEach((el) => el.classList.remove('fw-bold'))
    }

    // Обновляем статистику
    updateStatistics(allLetters)
  } catch (err) {
    showError('Не удалось пометить письмо как прочитанное')
  }
}

function updateLetterBadges(letter) {
  const badgesContainer = document.querySelector(
    '#letter-content .d-flex.flex-wrap.gap-2.mb-3'
  )
  if (!badgesContainer) return

  const folderName = displayNameForFolder(normalizeFolder(letter.folder))
  const isUnread = Number(letter.is_read) === 0

  const badges = [
    `<span class="badge bg-primary">${folderName}</span>`,
    isUnread ? '<span class="badge bg-warning">Непрочитано</span>' : '',
  ]
    .filter(Boolean)
    .join(' ')

  badgesContainer.innerHTML = badges
}

function setupLetterActionButtons(letterId, letterData) {
  const buttonContainer =
    document.querySelector('#letter-content .d-flex.gap-2') ||
    (() => {
      // создадим контейнер, если его нет
      const letterContent = document.getElementById('letter-content')
      if (!letterContent) return null
      const div = document.createElement('div')
      div.className = 'd-flex gap-2 mt-3'
      letterContent.appendChild(div)
      return div
    })()
  if (!buttonContainer) return
  buttonContainer.innerHTML = ''

  // Кнопка "Ответить"
  const replyBtn = document.createElement('button')
  replyBtn.className = 'btn btn-primary'
  replyBtn.setAttribute('type', 'button')
  replyBtn.setAttribute('aria-label', 'Ответить на письмо')
  replyBtn.innerHTML =
    '<i class="bi bi-reply me-1" aria-hidden="true"></i> Ответить'
  replyBtn.addEventListener('click', () => {
    replyToLetter(letterData)
  })
  buttonContainer.appendChild(replyBtn)

  // Кнопка "Прочитано" / "Непрочитано" (действие)
  const toggleReadBtn = document.createElement('button')
  toggleReadBtn.className = 'btn btn-outline-secondary'
  toggleReadBtn.setAttribute('type', 'button')
  toggleReadBtn.setAttribute(
    'aria-label',
    'Изменить статус прочитано/непрочитано'
  )
  toggleReadBtn.innerHTML =
    Number(letterData.is_read) === 0
      ? '<i class="bi bi-check-circle me-1" aria-hidden="true"></i> Прочитано'
      : '<i class="bi bi-envelope me-1" aria-hidden="true"></i> Непрочитано'
  toggleReadBtn.addEventListener('click', async () => {
    await toggleReadStatus(letterId)
  })
  buttonContainer.appendChild(toggleReadBtn)

  // Кнопка "Переслать"
  const forwardBtn = document.createElement('button')
  forwardBtn.className = 'btn btn-outline-primary'
  forwardBtn.setAttribute('type', 'button')
  forwardBtn.setAttribute('aria-label', 'Переслать письмо')
  forwardBtn.innerHTML =
    '<i class="bi bi-forward me-1" aria-hidden="true"></i> Переслать'
  forwardBtn.addEventListener('click', () => {
    forwardLetter(letterData)
  })
  buttonContainer.appendChild(forwardBtn)

  // Spacer
  const spacer = document.createElement('div')
  spacer.className = 'ms-auto'
  buttonContainer.appendChild(spacer)

  // Кнопка "Удалить"
  const deleteBtn = document.createElement('button')
  deleteBtn.className = 'btn btn-outline-danger'
  deleteBtn.setAttribute('type', 'button')
  deleteBtn.setAttribute('aria-label', 'Удалить письмо')
  deleteBtn.innerHTML =
    '<i class="bi bi-trash me-1" aria-hidden="true"></i> Удалить'
  deleteBtn.addEventListener('click', () => {
    deleteLetter(letterId)
  })

  // Если это черновик — добавляем кнопку редактирования (prepend, чтобы была слева)
  if (normalizeFolder(letterData.folder) === 'draft') {
    const editBtn = document.createElement('button')
    editBtn.className = 'btn btn-warning'
    editBtn.setAttribute('type', 'button')
    editBtn.setAttribute('aria-label', 'Редактировать черновик')
    editBtn.innerHTML =
      '<i class="bi bi-pencil me-1" aria-hidden="true"></i> Продолжить редактирование'
    editBtn.addEventListener('click', () => {
      editDraft(letterData)
    })
    // поместим в начало
    buttonContainer.prepend(editBtn)
  }

  buttonContainer.appendChild(deleteBtn)
}

// -----------------------------
// Refresh / statistics
// -----------------------------
async function refreshAllData() {
  showLoading('Обновление данных...')
  try {
    if (api.clearCache) api.clearCache()
    const response = await api.getLetters()
    if (response && response.success) {
      allLetters = Array.isArray(response.data) ? response.data : []
      updateStatistics(allLetters)
      // Обновляем отображаемые письма для текущей папки, но не выбираем автоматически письмо:
      await filterLettersByFolder(currentFolder, { selectFirst: false })
    } else {
      throw new Error('Неверный формат ответа сервера')
    }
  } catch (err) {
    showError(`Ошибка обновления: ${err.message}`)
  } finally {
    hideLoading()
  }
}

function findStatisticsElement() {
  // Ищем карточку с заголовком "Статистика"
  const cards = document.querySelectorAll('.card')
  for (const card of cards) {
    const header = card.querySelector('.card-header')
    if (
      header &&
      header.textContent &&
      header.textContent.trim().includes('Статистика')
    ) {
      const body = card.querySelector('.card-body')
      if (body) return body
    }
  }
  // fallback: первый .card-body
  return document.querySelector('.card-body')
}

function updateStatistics(letters = []) {
  const source = letters && letters.length ? letters : allLetters

  const total = source.length
  const unread = source.filter((l) => Number(l.is_read) === 0).length

  const inbox = source.filter(
    (l) => normalizeFolder(l.folder) === 'inbox'
  ).length
  const sent = source.filter((l) => normalizeFolder(l.folder) === 'sent').length
  const draft = source.filter(
    (l) => normalizeFolder(l.folder) === 'draft'
  ).length
  const trash = source.filter(
    (l) => normalizeFolder(l.folder) === 'trash'
  ).length

  // Обновляем бейджи (поддерживаем одинаковые id/badge в HTML)
  updateFolderCount('inbox', inbox)
  updateFolderCount('sent', sent)
  updateFolderCount('draft', draft)
  updateFolderCount('trash', trash)

  const statsElement = findStatisticsElement()
  if (statsElement) {
    statsElement.innerHTML = `
      <p class="mb-1">Всего писем: <strong>${total}</strong></p>
      <p class="mb-1">Непрочитанных: <strong class="text-danger">${unread}</strong></p>
      <p class="mb-0">Отправлено: <strong>${sent}</strong></p>
    `
  }
}

function updateFolderCount(folderKey, count) {
  const folderElement = document.querySelector(
    `[data-folder="${folderKey}"] .badge`
  )
  if (!folderElement) return
  folderElement.textContent = count
  folderElement.className =
    count > 0 ? 'badge bg-primary float-end' : 'badge bg-secondary float-end'
}

// -----------------------------
// New letter form (send/save draft)
// -----------------------------
function setupNewLetterForm() {
  const form =
    document.querySelector('#new-letter-form form') ||
    document.getElementById('compose-form')
  if (form) {
    form.addEventListener('submit', async function (e) {
      e.preventDefault()
      await sendNewLetter()
    })
  }

  const saveDraftBtn = document.getElementById('save-draft-btn')
  if (saveDraftBtn) {
    saveDraftBtn.addEventListener('click', async function () {
      const toEmail = document.getElementById('new-to-email').value.trim()
      const subject = document.getElementById('new-subject').value.trim()
      const body = document.getElementById('new-body').value.trim()

      // Для черновика все поля не обязательны
      if (!subject && !body) {
        showError('Черновик не может быть пустым')
        return
      }

      const letterData = {
        to_email: toEmail || '',
        subject: subject || 'Черновик',
        body: body || '',
        folder: 'draft',
        is_read: 1,
      }

      showLoading('Сохранение черновика...')
      try {
        const response = await api.createLetter(letterData)
        if (response && response.success) {
          showSuccess('Черновик сохранен!')
          clearNewLetterForm()
          hideNewLetterForm()

          // Переключаем текущую папку на черновики перед обновлением,
          // чтобы после refresh остаться в черновиках
          currentFolder = 'draft'
          persistFolder(currentFolder)

          await refreshAllData()
          await selectFolder('draft', null, { selectFirst: true })
        } else {
          throw new Error(response.error || 'Ошибка сохранения')
        }
      } catch (err) {
        showError(`Не удалось сохранить черновик: ${err.message}`)
      } finally {
        hideLoading()
      }
    })
  }

  const cancelBtn = document.getElementById('cancel-new-letter')
  if (cancelBtn) cancelBtn.addEventListener('click', hideNewLetterForm)
}

function clearNewLetterForm() {
  const to = document.getElementById('new-to-email')
  const subj = document.getElementById('new-subject')
  const body = document.getElementById('new-body')
  if (to) to.value = ''
  if (subj) subj.value = ''
  if (body) body.value = ''
}

function showNewLetterForm(keepData = false) {
  const form = document.getElementById('new-letter-form')
  const content = document.getElementById('letter-content')
  const noSelected = document.getElementById('no-letter-selected')
  const formMessage = document.getElementById('form-message')

  if (!keepData) clearNewLetterForm()
  if (formMessage) formMessage.style.display = 'block' // показываем подсказку
  if (form) form.style.display = 'block'
  if (content) content.style.display = 'none'
  if (noSelected) noSelected.style.display = 'none'
  if (form) form.scrollIntoView({ behavior: 'smooth' })
}

function hideNewLetterForm() {
  const form = document.getElementById('new-letter-form')
  const content = document.getElementById('letter-content')
  const noSelected = document.getElementById('no-letter-selected')
  const formMessage = document.getElementById('form-message')
  if (form) form.style.display = 'none'
  if (formMessage) formMessage.style.display = 'none'

  if (currentLetterId) {
    if (content) content.style.display = 'block'
  } else {
    if (noSelected) noSelected.style.display = 'block'
  }
}

async function sendNewLetter() {
  const toEmail = document.getElementById('new-to-email').value.trim()
  const subject = document.getElementById('new-subject').value.trim()
  const body = document.getElementById('new-body').value.trim()

  if (!toEmail || !toEmail.includes('@')) {
    showError('Введите корректный email адрес')
    document.getElementById('new-to-email').focus()
    return
  }
  if (!subject) {
    showError('Введите тему письма')
    document.getElementById('new-subject').focus()
    return
  }
  if (!body) {
    showError('Введите текст письма')
    document.getElementById('new-body').focus()
    return
  }

  const formData = {
    to_email: toEmail,
    subject: subject,
    body: body,
    folder: 'sent',
    from_email: 'student@college.ru',
  }

  showLoading('Отправка письма...')
  try {
    const result = await api.createLetter(formData)
    if (result && result.success) {
      // Получаем объект отправленного письма, если сервер вернул его
      const created = result.data || null

      showSuccess('Письмо успешно отправлено!')
      clearNewLetterForm()
      hideNewLetterForm()

      // Если сервер вернул объект — добавим его локально как непрочитанный и откроем без запроса к серверу
      if (created && created.id) {
        // гарантируем статус непрочитано локально
        created.is_read = 0

        // удалим возможные дубликаты и положим новый в начало
        allLetters = allLetters.filter((l) => l.id !== created.id)
        allLetters.unshift(created)

        // переключаем текущую папку на отправленные локально
        currentFolder = 'sent'
        persistFolder(currentFolder)

        // отобразим локально отправленные (без сетевых запросов)
        const sentLetters = allLetters.filter(
          (l) => normalizeFolder(l.folder) === 'sent'
        )
        displayLettersWithPagination(sentLetters)
        updateStatistics(allLetters)

        // дождёмся рендера, найдём элемент и визуально пометим его непрочитанным
        await new Promise((res) => setTimeout(res, 60))
        const el = document.querySelector(
          `#letter-list [data-id="${created.id}"]`
        )
        if (el) {
          // визуально пометим как непрочитанное
          el.classList.add('unread')
          const senderEl = el.querySelector('h6')
          const subjEl = el.querySelector('p')
          if (senderEl && !senderEl.classList.contains('fw-bold'))
            senderEl.classList.add('fw-bold')
          if (subjEl && !subjEl.classList.contains('fw-bold'))
            subjEl.classList.add('fw-bold')

          // откроем письмо, но НЕ будем помечать его как прочитанное и НЕ будем грузить с сервера
          await selectLetter(created.id, el, {
            markReadOnSelect: false,
            loadFromServer: false,
          })
        } else {
          // фолбек: покажем первый элемент
          await filterLettersByFolder('sent', { selectFirst: true })
        }
      } else {
        // если сервер не вернул объект — fallback: обновим список с сервера и откроем отправленные
        currentFolder = 'sent'
        persistFolder(currentFolder)
        await refreshAllData()
        await selectFolder('sent', null, { selectFirst: true })
      }
    } else {
      throw new Error(result.error || 'Ошибка отправки')
    }
  } catch (err) {
    showError(`Ошибка отправки: ${err.message}`)
  } finally {
    hideLoading()
  }
}

// -----------------------------
// Search / filtering
// -----------------------------
function filterLettersBySearch(searchTerm) {
  if (!searchTerm || !searchTerm.trim()) {
    filterLettersByFolder(currentFolder, { selectFirst: false })
    return
  }

  const term = searchTerm.toLowerCase().trim()
  const filtered = allLetters.filter((letter) => {
    return (
      (letter.subject && letter.subject.toLowerCase().includes(term)) ||
      (letter.body && letter.body.toLowerCase().includes(term)) ||
      (letter.from_email && letter.from_email.toLowerCase().includes(term)) ||
      (letter.to_email && letter.to_email.toLowerCase().includes(term))
    )
  })

  displayedLetters = filtered.filter(
    (l) =>
      normalizeFolder(l.folder) === currentFolder || currentFolder === 'all'
  )
  displayLetters(displayedLetters)
}

// -----------------------------
// Helpers / utilities
// -----------------------------
function updateCurrentDate() {
  const now = new Date()
  const options = {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }
  const dateString = now.toLocaleDateString('ru-RU', options)
  const el = document.getElementById('current-date')
  if (el) el.textContent = `Загружено: ${dateString}`
}

function resetLetterSelection() {
  currentLetterId = null
  const noSelected = document.getElementById('no-letter-selected')
  const content = document.getElementById('letter-content')
  if (noSelected) noSelected.style.display = 'block'
  if (content) content.style.display = 'none'
  document
    .querySelectorAll(
      '.letter-list .list-group-item, #letter-list .list-group-item'
    )
    .forEach((item) => item.classList.remove('active-letter'))
}

function formatDate(dateString) {
  if (!dateString) return 'Без даты'

  try {
    const date = new Date(dateString)
    if (isNaN(date.getTime())) return 'Неверная дата'

    const now = new Date()
    const diff = now - date

    if (
      diff < 24 * 60 * 60 * 1000 &&
      date.getDate() === now.getDate() &&
      date.getMonth() === now.getMonth() &&
      date.getFullYear() === now.getFullYear()
    ) {
      return date.toLocaleTimeString('ru-RU', {
        hour: '2-digit',
        minute: '2-digit',
      })
    }

    const yesterday = new Date(now)
    yesterday.setDate(yesterday.getDate() - 1)
    if (
      date.getDate() === yesterday.getDate() &&
      date.getMonth() === yesterday.getMonth() &&
      date.getFullYear() === yesterday.getFullYear()
    ) {
      return 'Вчера'
    }

    if (diff < 7 * 24 * 60 * 60 * 1000) {
      const days = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб']
      return days[date.getDay()]
    }

    return date.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })
  } catch (e) {
    return 'Неверная дата'
  }
}

function truncateText(text, maxLength) {
  if (!text) return ''
  return text.length <= maxLength ? text : text.substring(0, maxLength) + '...'
}

function escapeHtml(text) {
  if (text == null) return ''
  const div = document.createElement('div')
  div.textContent = String(text)
  return div.innerHTML
}

function setTextContent(selector, text) {
  const el = document.querySelector(selector)
  if (el) el.textContent = text
}

// Debounce
function debounce(fn, wait) {
  let t = null
  return function (...args) {
    clearTimeout(t)
    t = setTimeout(() => fn.apply(this, args), wait)
  }
}

// -----------------------------
// Notifications / loaders
// -----------------------------
function showError(message) {
  createToast(message, 'danger', 5000)
}

function showSuccess(message) {
  createToast(message, 'success', 6000)
}

function createToast(message, type = 'info', ttl = 3000) {
  const div = document.createElement('div')
  div.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 end-0 m-3`
  div.style.zIndex = 9999

  // accessibility
  div.setAttribute('role', 'alert')
  div.setAttribute('aria-live', 'assertive')

  div.innerHTML = `
    ${escapeHtml(message)}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Закрыть уведомление"></button>
  `
  document.body.appendChild(div)
  setTimeout(() => {
    if (div.parentNode) div.remove()
  }, ttl)
}

function showLoading(message = 'Загрузка...') {
  let loader = document.getElementById('global-loader')
  if (!loader) {
    loader = document.createElement('div')
    loader.id = 'global-loader'
    loader.className = 'position-fixed top-50 start-50 translate-middle'
    loader.style.zIndex = '99999'

    // accessibility
    loader.setAttribute('role', 'status')
    loader.setAttribute('aria-live', 'polite')
    loader.setAttribute('aria-label', 'Загрузка данных')

    loader.innerHTML = `
      <div class="d-flex align-items-center bg-white p-3 rounded shadow">
        <div class="spinner-border text-primary me-3" aria-hidden="true"></div>
        <div class="loader-message">${escapeHtml(message)}</div>
      </div>
    `
    document.body.appendChild(loader)
  } else {
    const msg = loader.querySelector('.loader-message')
    if (msg) msg.textContent = message
    loader.style.display = 'block'
  }
}

function hideLoading() {
  const loader = document.getElementById('global-loader')
  if (loader) loader.style.display = 'none'
}

// -----------------------------
// Toggle read / delete / reply / forward
// -----------------------------
async function toggleReadStatus(letterId) {
  if (!letterId) {
    showError('Не выбрано письмо')
    return
  }

  showLoading('Изменение статуса...')
  try {
    const resp = await api.getLetterById(letterId)
    if (!resp || !resp.success) throw new Error('Ошибка загрузки письма')

    const currentStatus = Number(resp.data.is_read) === 1
    const newStatus = currentStatus ? 0 : 1

    const updateResp = await api.updateLetter(letterId, { is_read: newStatus })
    if (!updateResp || !updateResp.success) throw new Error('Ошибка обновления')

    showSuccess(
      newStatus === 1 ? 'Пометка как прочитанное' : 'Пометка как непрочитанное'
    )

    if (currentLetterId) await selectLetter(letterId)
    await refreshAllData()
  } catch (error) {
    showError(`Ошибка: ${error.message}`)
  } finally {
    hideLoading()
  }
}

// Удаление письма (перемещение в корзину)
async function deleteLetter(letterId) {
  if (!letterId) {
    showError('Не выбрано письмо для удаления')
    return
  }

  if (
    !confirm(
      'Вы уверены, что хотите удалить это письмо? Оно будет перемещено в корзину.'
    )
  ) {
    return
  }

  showLoading('Удаление письма...')
  try {
    const response = await api.deleteLetter(letterId)

    if (response && response.success) {
      showSuccess('Письмо перемещено в корзину')

      // установим текущую папку на корзину и обновим
      currentFolder = 'trash'
      persistFolder(currentFolder)

      await refreshAllData()
      await selectFolder('trash', null, { selectFirst: true })
      resetLetterSelection()
      await refreshAllData() // обновим статистику ещё раз для уверенности
    } else {
      throw new Error(response.error || 'Ошибка удаления')
    }
  } catch (error) {
    showError(`Не удалось удалить письмо: ${error.message}`)
  } finally {
    hideLoading()
  }
}

// Ответить на письмо
function replyToLetter(letterData) {
  // Открываем форму и сохраняем данные (не очищаем)
  showNewLetterForm(true)

  const toEmail = document.getElementById('new-to-email')
  const subject = document.getElementById('new-subject')
  const body = document.getElementById('new-body')

  const replyTo = letterData.from_email || letterData.sender_email || ''
  if (toEmail) toEmail.value = replyTo

  const originalSubject = letterData.subject || ''
  if (!originalSubject.toLowerCase().startsWith('re:')) {
    if (subject) subject.value = `Re: ${originalSubject}`
  } else {
    if (subject) subject.value = originalSubject
  }

  const originalBody = letterData.body || ''
  const quote = `\n\n---\n${originalBody.substring(0, 500)}${
    originalBody.length > 500 ? '...' : ''
  }`
  if (body) body.value = `Здравствуйте!\n\n${quote}`

  // Фокус в поле текста, курсор в конце
  setTimeout(() => {
    if (body) {
      body.focus()
      const len = body.value.length
      body.setSelectionRange(len, len)
    }
  }, 100)
}

// Переслать письмо
function forwardLetter(letterData) {
  // Открываем форму и сохраняем данные (не очищаем)
  showNewLetterForm(true)

  const toEmail = document.getElementById('new-to-email')
  const subject = document.getElementById('new-subject')
  const body = document.getElementById('new-body')

  // Очищаем поле "Кому"
  if (toEmail) toEmail.value = ''

  // Добавляем Fwd: к теме
  const originalSubject = letterData.subject || ''
  if (
    !originalSubject.toLowerCase().startsWith('fw:') &&
    !originalSubject.toLowerCase().startsWith('fwd:')
  ) {
    if (subject) subject.value = `Fwd: ${originalSubject}`
  } else {
    if (subject) subject.value = originalSubject
  }

  // Информация о пересылаемом письме
  const forwardInfo = `\n\n--- Пересылаемое письмо ---\n`
  const fromInfo = `От: ${letterData.from_email || letterData.sender_email}\n`
  const dateInfo = `Дата: ${formatDate(
    letterData.date || letterData.created_at
  )}\n`
  const subjectInfo = `Тема: ${letterData.subject}\n`
  const bodyContent = `\n${letterData.body || ''}`

  if (body)
    body.value = forwardInfo + fromInfo + dateInfo + subjectInfo + bodyContent

  // Фокус в поле текста
  setTimeout(() => {
    if (body) {
      body.focus()
      const len = body.value.length
      body.setSelectionRange(len, len)
    }
  }, 100)
}

// Редактирование черновика
function editDraft(letter) {
  currentLetterId = letter.id
  showNewLetterForm(true)
  document.getElementById('new-to-email').value = letter.to_email || ''
  document.getElementById('new-subject').value = letter.subject || ''
  document.getElementById('new-body').value = letter.body || ''
}

console.group('Финальное тестирование')
console.log('1. Загрузка приложения:', typeof api !== 'undefined')
console.log(
  '2. Форма нового письма:',
  document.getElementById('new-letter-form') !== null
)
console.groupEnd()
