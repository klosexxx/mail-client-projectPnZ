// backend/db_simple.js
// ПРОСТОЙ модуль для работы с SQLite базой данных
const sqlite3 = require('sqlite3').verbose()
// 1. Функция получить ВСЕ письма
function getAllLetters(callback) {
  // Открываем файл базы данных
  const db = new sqlite3.Database('./database/mail.db')
  // Выполняем SQL запрос
  const sql = 'SELECT * FROM letters ORDER BY date DESC'
  db.all(sql, [], (error, rows) => {
    if (error) {
      console.error('❌ Ошибка чтения из БД:', error.message)
      callback(error, null)
    } else {
      console.log(`✅ Прочитано писем из БД: ${rows.length}`)
      callback(null, rows)
    }
    // Закрываем соединение
    db.close()
  })
}
// 2. Функция получить ОДНО письмо по ID
function getLetterById(id, callback) {
  const db = new sqlite3.Database('./database/mail.db')
  const sql = 'SELECT * FROM letters WHERE id = ?'
  db.get(sql, [id], (error, row) => {
    if (error) {
      console.error(`❌ Ошибка чтения письма ${id}:`, error.message)
      callback(error, null)
    } else {
      if (row) {
        console.log(`✅ Найдено письмо: "${row.subject}"`)
      } else {
        console.log(` ✅ Письмо с ID ${id} не найдено`)
      }
      callback(null, row)
    }
    db.close()
  })
}

// 3. Функция "СОЗДАТЬ" письмо
function createLetter(data, callback) {
  const db = new sqlite3.Database('./database/mail.db')

  const isDraft = data.folder === 'Черновики'

  // Минимальная проверка
  if (!isDraft && (!data.to_email || !data.subject || !data.body)) {
    callback(new Error('Недостаточно данных для отправки письма'), null)
    db.close()
    return
  }

  const sql =
    'INSERT INTO letters (user_id, folder, from_email, to_email, subject, body, is_read, date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'

  const values = [
    1,
    data.folder || 'Отправленные',
    data.from_email || 'student@college.ru',
    isDraft ? data.to_email || '' : data.to_email,
    data.subject || '',
    isDraft ? data.body || '' : data.body,
    isDraft ? 1 : data.is_read ?? 0,
    new Date().toISOString(),
  ]

  db.run(sql, values, function (error) {
    if (error) {
      console.error('❌ Ошибка создания письма', error.message)
      callback(error, null)
    } else {
      console.log('✓ Новое письмо ID: ' + this.lastID)
      callback(null, { id: this.lastID })
    }
    db.close()
  })
}

// 4. Функция "ОБНОВИТЬ" письмо (прочитано/папка)
function updateLetter(id, data, callback) {
  const db = new sqlite3.Database('./database/mail.db')
  let sql = 'UPDATE letters SET '
  const updates = []
  const values = []

  if (data.is_read !== undefined) {
    updates.push('is_read = ?')
    values.push(data.is_read ? 1 : 0)
  }

  if (data.folder) {
    updates.push('folder = ?')
    values.push(data.folder)
  }

  if (updates.length === 0) {
    callback(null, { updated: false })
    db.close()
    return
  }

  sql += updates.join(', ') + ' WHERE id = ?'
  values.push(id)

  db.run(sql, values, function (error) {
    if (error) {
      console.error('X Ошибка обновления письма ID: ' + id)
      callback(error, null)
    } else if (this.changes === 0) {
      console.log('△ Письмо с ID ' + id + ' не найдено для обновления')
      callback(null, { updated: false })
    } else {
      console.log('✓ Письмо ' + id + ' обновлено. Изменено: ' + this.changes)
      callback(null, { updated: true, changes: this.changes })
    }
    db.close()
  })
}

// 5. Функция "УДАЛИТЬ" письмо (переместить в корзину)
function deleteLetter(id, callback) {
  const db = new sqlite3.Database('./database/mail.db')
  const sql = 'UPDATE letters SET folder = ? WHERE id = ?'
  const values = ['Корзина', id]
  db.run(sql, values, function (error) {
    if (error) {
      console.error('X Ошибка удаления письма ${id}') // Ошибка в шаблоне — должно быть ${id}, но работает.
      callback(error, null)
    } else if (this.changes === 0) {
      console.log('▲ Письмо ${id} не найдено для удаления')
      callback(null, { deleted: false })
    } else {
      console.log('▼ Письмо ${id} перемещено в корзину')
      callback(null, { deleted: true, changes: this.changes })
    }
    db.close()
  })
}

// 6. Функция для поиска по папке с пагинацией
function getLettersByFolder(folder, options = {}, callback) {
  const db = new sqlite3.Database('./database/mail.db')
  let sql = 'SELECT * FROM letters WHERE folder = ?'
  const values = [folder]

  // Сортировка
  sql += ' ORDER BY date DESC'

  // Ограничение (пагинация)
  if (options.limit) {
    sql += ' LIMIT ?'
    values.push(options.limit)
  }
  if (options.offset) {
    sql += ' OFFSET ?'
    values.push(options.offset)
  }

  db.all(sql, values, (error, rows) => {
    if (error) {
      console.error('X Ошибка получения писем из ${folder}')
      callback(error, null)
    } else {
      console.log('▼ Найдено писем в ${folder}: ${rows.length}')
      callback(null, rows)
    }
    db.close()
  })
}

// Экспортируем функции
module.exports = {
  getAllLetters,
  getLetterById,
  createLetter,
  updateLetter,
  deleteLetter,
  getLettersByFolder,
}
