const db = require('./db_simple.js')

// Тест: Получить все письма
db.getAllLetters((error, letters) => {
  if (error) {
    console.error('Ошибка:', error)
  } else {
    console.log('Письма из БД:', letters)
  }
})

// Тест: Получить письмо по ID (например, ID 1)
db.getLetterById(1, (error, letter) => {
  if (error) {
    console.error('Ошибка:', error)
  } else {
    console.log('Письмо по ID:', letter)
  }
})
