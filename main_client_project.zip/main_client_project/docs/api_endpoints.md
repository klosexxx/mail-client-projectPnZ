# API ENDPOINTS

## ТАБЛИЦА ENDPOINTS

| Метод | URL          | Описание               | Параметры                  |
|-------|--------------|------------------------|----------------------------|
| GET   | /letters     | Получить список писем  | folder (фильтр по папке)   |
| POST  | /letters     | Создать новое письмо   | {to, subject, body}        |
| GET   | /letters/:id | Получить письмо        | Нет                        |
| PATCH | /letters/:id | Обновить письмо        | {is_read, folder}          |
| DELETE| /letters/:id | Удалить письмо         | Нет                        |

## ПОДРОБНОЕ ОПИСАНИЕ

## 1. GET /letters  
   Получить список писем  
   Пример запроса: GET http://localhost:3000/api/letters?folder=inbox  
   Пример ответа:  
   ```json  
   [  
     {  
       "id": 1,  
       "from": "teacher@school.ru",  
       "subject": "Задание на практику",  
       "body": "Короткий текст...",  
       "is_read": false,  
       "created_at": "2024-05-20 10:00"  
     }  
   ]
   ```
   
## 2. GET /letters/:id
Получить одно письмо
Пример запроса: GET http://localhost:3000/api/letters/1
Пример ответа:  
   ```json  
   [  
    {
        "id": 1,  
        "from": "teacher@school.ru",  
        "to": "student@college.ru",  
        "subject": "Задание на практику",  
        "body": "Уважаемый студент! Нужно разработать...",  
        "is_read": false,  
        "created_at": "2024-05-20 10:00"  
    }
   ]
   ```

## 3. POST /letters
Отправить письмо
Тело запроса:
```json  
   [  
    {  
        "to": "friend@mail.ru",  
        "subject": "Привет",  
        "body": "Как дела?"  
    }
   ]
```

## 4.  PATCH /letters/:id
Обновить письмо (пометить прочитанным или переместить)
Тело запроса:
```json  
    [  
    {  
        "is_read": true  
    }
    ]  
```
## 5.  DELETE /letters/:id
Удалить письмо
Пример запроса: DELETE http://localhost:3000/api/letters/1
Пример ответа:
```json  
    [  
    {  
        "success": true  
    }
    ]  
```    